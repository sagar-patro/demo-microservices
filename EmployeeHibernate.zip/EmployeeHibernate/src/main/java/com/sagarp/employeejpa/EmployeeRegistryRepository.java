package com.sagarp.employeejpa;

import org.springframework.data.repository.CrudRepository;

public interface EmployeeRegistryRepository extends CrudRepository<EmployeeRegistry, Long> {

}
